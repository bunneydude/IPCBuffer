#include <msp430g2553.h>
#include <stdint.h>
#include "nrf24.h"
#include "nRF24L01.h"
#include "main.h"
#include "TI_aes_128.h"

#define UART_TXD   0x04                     // TXD on P1.2
#define UART_RXD   0x02                     // RXD on P1.1

#define RING_SIZE 8

#define SERIAL_REGISTER_NUM 16

#define POUT_CS P1OUT
#define POUT_CE P1OUT

#define CS_BIT 0x10
#define CE_BIT 0x08


// Global variables

// UART
uint8_t txData;                     
uint8_t rxBuffer;                    
uint8_t rxResponse;
volatile uint8_t received_bytes[RING_SIZE];
volatile uint8_t tail = 0;
volatile uint8_t head = 0;
uint8_t serial_registers[SERIAL_REGISTER_NUM];

// Serial protocol
uint8_t byte_number = 0;
uint8_t function = 0;
uint8_t address = 0;
uint8_t write_data = 0;
uint8_t checksum = 0;
uint8_t executePacket = 0;
uint8_t return_data = 90; //"A" (65) is good, "Z" (90) is bad

//counters
volatile uint16_t task_hbt = TASK_HBT_PERIOD;
volatile uint16_t task_tx = 0;//TASK_TX_PERIOD;
volatile uint16_t task_pins = TASK_DEBOUNCE;
volatile uint16_t task_encrypt = TASK_HBT_PERIOD;

//state
uint8_t hbt_output = 0;
uint8_t pin2_output = 0;
volatile uint8_t last_pin_state = 0;

//------------------------------------------------------------------------------
// Function prototypes
//------------------------------------------------------------------------------

// Inits
void UART0_init(void);
void Timer0_init(void);

// Peripherals 
void UART0_tx(uint8_t byte);

// Serial protocol
uint8_t ring_read(uint8_t *data);
void ring_write(uint8_t data);
void serial_respond(void);

// Radio
void nrfTX(uint8_t pin_state);

uint8_t tx_address[5] = {0xE7,0xE7,0xE7,0xE7,0xE7};
uint8_t rx_address[5] = {0xD7,0xD7,0xD7,0xD7,0xD7};

uint8_t spi_transfer(uint8_t tx) //blocking spi transfer
{
  UCB0TXBUF = tx; 
  while ((IFG2 & UCB0RXIFG) == 0x00);
  return UCB0RXBUF;
}


//could just replace the following two functions with the proper bit manipulation everywhere in nrf24.c, but for simplicity for your sake I kept them here
void nrf24_ce_digitalWrite(uint8_t state){
  if (state == 0){
    POUT_CE &= ~CE_BIT;
  }else{
    POUT_CE |= CE_BIT;
  }
}

void nrf24_csn_digitalWrite(uint8_t state){
  if (state == 0){
    POUT_CS &= ~CS_BIT;
  }else{
    POUT_CS |= CS_BIT;
  }
}

void main(void)
{
  WDTCTL = WDTPW + WDTHOLD; // Stop watchdog timer

  DCOCTL = 0x00; // Set DCOCLK to 1MHz
  BCSCTL1 = CALBC1_1MHZ; //set range, 0x10FF
  BCSCTL1 &= ~(1<<6);
  DCOCTL = CALDCO_1MHZ; //set DCO step + modulation, 0x10FE

  BCSCTL3 |= LFXT1S1; //set VLOCLK as src for ACLK

  __enable_interrupt();
  UART0_init();                  
  Timer0_init();

  P1OUT = 0x00;  
  P1DIR = 0xFF;

  P1SEL |= BIT5 + BIT6 + BIT7; //enable secondary functions
  P1SEL2 |= BIT5 + BIT6 + BIT7;  

  P2DIR = 0x00; //inputs
  P2OUT = 0x3F; //pullup
  P2REN = 0x3F; //enable all 6 pullups

  PDIR_HBT |= HBT;
  POUT_HBT |= HBT;

  P1OUT |= BIT4;
  P2OUT |= BIT3;

  UCB0CTL1 |= UCSWRST;
  UCB0CTL0 |= UCCKPH + UCMSB + UCMST + UCSYNC;
  UCB0CTL1 |= UCSSEL_2; //SMCLK, 1MHz
  UCB0BR0 |= 0x02;      // /2
  UCB0BR1 = 0;                      
  UCB0CTL1 &= ~UCSWRST; // init USCI state machine**

  POUT_CS |= CS_BIT;
  POUT_CE &= ~CE_BIT;

  nrf24_init();
  nrf24_config(2,16); //set payload to 16
  nrf24_tx_address(tx_address);
  nrf24_rx_address(rx_address);  

  rxBuffer = 1;

  while(1){

    if(1 == task_hbt){ task_hbt = TASK_HBT_PERIOD; POUT_HBT ^= HBT;}  
    if(1 == task_pins){
      task_pins = TASK_DEBOUNCE;
      uint8_t current_pin_state = P2IN;
      if(current_pin_state != last_pin_state){
	last_pin_state = current_pin_state;
	nrfTX(current_pin_state);
      }
    }

    serial_respond(); //only sends in responds to something

  }
}

void nrfTX(uint8_t pin_state){

  uint8_t data_array[] = {pin_state, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 
    0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff};

  uint8_t  key[]   = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f};

  aes_enc_dec(data_array,key,0); //encrypt, store in data_array

  nrf24_send(data_array);     

  while(nrf24_isSending());

  serial_registers[15] = nrf24_lastMessageStatus(); 
  serial_registers[14] = nrf24_retransmissionCount();

  nrf24_powerUpRx();

}


void serial_respond(void){
  while(ring_read(&rxBuffer)){ //get bytes from buffer
    byte_number++;
    switch(byte_number){
      case(1):
	function = rxBuffer & 0x80; //0x80 = write, 0x00 = read
	address = rxBuffer & 0x0F; //for 16 registers
	break;
      case(2):
	write_data = rxBuffer;
	break;
      case(3):
	if(rxBuffer == checksum){executePacket = 1;}
	break;
	//for now, don't send twice before receiving once
    }
    checksum += rxBuffer;
  }

  if(byte_number==3){ //parse received bytes
    if(executePacket == 1){
      if(function == 0x80){ 
	serial_registers[address] = write_data;
	return_data = 65;
      }else if(function == 0x00){
	return_data = serial_registers[address];  
      }else if(function == 0x40){ //spi      
	POUT_CS &= ~CS_BIT;
	UCB0TXBUF = 0x00; 
	while ((IFG2 & UCB0RXIFG) == 0x00);
	serial_registers[2] = UCB0RXBUF;
	UCB0TXBUF = 0x00;	  
	while ((IFG2 & UCB0RXIFG) == 0x00);
	serial_registers[3] = UCB0RXBUF;
	POUT_CS |= CS_BIT;
      }
      UART0_tx(return_data);
      executePacket = 0;
      byte_number = 0;
      checksum = 0;
    }else{ //received enough bytes, but malformed
      byte_number = 0;
      checksum = 0;
      UART0_tx(90);
    }
  }
}

#pragma vector = USCIAB0RX_VECTOR
__interrupt void UART_A0_RX_ISR(void){

  ring_write(UCA0RXBUF);
}

#pragma vector = TIMER0_A0_VECTOR
__interrupt void timer_0_ISR(void){ //fires at 1kHz
  if(1 < task_hbt){task_hbt--;}
  if(1 < task_pins){task_pins--;}
  if(1 < task_encrypt){task_encrypt--;}
  //tasks w/ counters of 0 are not scheduled
  //tasks are set to run when their counter reaches 1  
}

void UART0_init(void)
{    
  UCA0CTL1 |= UCSSEL1 + UCSWRST;
  UCA0BR0 = 104;
  UCA0BR1 = 0; //sum * 256 = prescalar
  UCA0MCTL |= (0 << 4) + (1 << 1); //UCBRF0 = 0, UCBRS0 = 1 for 1MHz
  P1SEL |= UART_TXD + UART_RXD;  // UART function
  P1SEL2 |= UART_TXD + UART_RXD; // UART function
  UCA0CTL1 &= ~UCSWRST; //clear
  UC0IE |= UCA0RXIE;  //enable rx interrupt
}

void Timer0_init(void){
  TACTL |= TASSEL0 + MC0; //use ACLK, about 12kHz
  TACCR0 = 12; // 12/12kHz = 0.001s
  TACCTL0 |= CCIE;  //interrupt will fire every millisecond
}

//TODO determine need of critical section (if any)
void ring_write(uint8_t data){
  //   __disable_interrupt();
  if( (tail + 1)%RING_SIZE != head){
    received_bytes[tail] = data;
    tail = (tail+1)%RING_SIZE; 
  }
  //   __enable_interrupt();  
}

uint8_t ring_read(uint8_t* data){
  //  __disable_interrupt();
  if(head != tail){      
    *data = received_bytes[head];
    head = (head+1)%RING_SIZE;
    //__enable_interrupt();      
    return 1;
  }else 
    //__enable_interrupt();      
    return 0;
}

void UART0_tx(uint8_t byte){
  while (UC0IFG & UCA0TXIFG == 0);  // Ensure last char got TX'd
  UCA0TXBUF = byte;
}
