#define PDIR_HBT P1DIR
#define POUT_HBT P1OUT
#define HBT 0x01

#define TASK_HBT_PERIOD 251 // 250ms
#define TASK_CHECK_ADC_PERIOD 6 // 5ms
#define TASK_SEND_WIFI_PERIOD 6 // 5ms
#define TASK_DEBOUNCE 21 //20ms

#define NOT_PRESSED 0
#define PRESSED 1
#define ROW_CHECK 2
#define DEBOUNCE 3
